"""FastAPI application package for Local Newsifier."""
