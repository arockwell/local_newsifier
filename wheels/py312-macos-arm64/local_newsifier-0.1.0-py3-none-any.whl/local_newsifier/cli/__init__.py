"""Local Newsifier CLI package."""
