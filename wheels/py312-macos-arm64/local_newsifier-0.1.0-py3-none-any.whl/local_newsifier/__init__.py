
"""Local Newsifier package initialization."""
