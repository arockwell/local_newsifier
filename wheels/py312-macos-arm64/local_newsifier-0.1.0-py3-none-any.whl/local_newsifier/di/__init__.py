"""
Dependency Injection module.

fastapi-injectable is now the sole dependency injection mechanism for
Local Newsifier. The migration from the custom DIContainer has been
fully completed.
"""
