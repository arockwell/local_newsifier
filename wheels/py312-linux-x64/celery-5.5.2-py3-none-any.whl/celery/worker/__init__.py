"""Worker implementation."""
from .worker import WorkController

__all__ = ('WorkController',)
